package com.practice.jwt1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jwt1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
